import React, { useState } from "react";
import "./App.css";

import Map from "./components/Map/Map";
import FloorPlanSettings from "./components/Configuration/FloorPlanSettings";
import Coordinate from "./utilities/Coordinate";

function App() {
  //State for storing floor plan overlays in leaflet.
  const [floorPlanGeoms, setFloorPlanGeoms] = useState([]);
  const [anchorPoint, setAnchorPoint] = useState(new Coordinate(-0.09, 51.505));

  function configurationChangedHandler(floorPlan, anchorPoint) {
    console.log("Floor Plan Changed:");
    console.log(floorPlan);
    setFloorPlanGeoms(floorPlan);
    console.log("Anchor Point Changed:");
    console.log(anchorPoint);
    setAnchorPoint(anchorPoint);
  }

  return (
    <div>
      <Map
        floorPlanGeoms={floorPlanGeoms}
        anchorPoint={anchorPoint}
        onConfigurationChanged={configurationChangedHandler}
      />
      <FloorPlanSettings
        floorPlan={floorPlanGeoms}
        anchorPoint={anchorPoint}
        onConfigurationChanged={configurationChangedHandler}
      />
    </div>
  );
}

export default App;
