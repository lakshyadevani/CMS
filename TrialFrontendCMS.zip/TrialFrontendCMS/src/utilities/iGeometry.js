class iGeometry {
    id;
    //Type can be Polyline or polygon or some other WKT. A string.
    type;
    //The coordinate information associated with the type. Usually an array
    //of Coordinate objects.
    coordinates;
    //Hex color code.
    fill;
    //Hex color code.
    stroke;

    //ranges between 0 and 1.
    opacity;

    //some decimal value.
    strokeWidth;
    constructor(id, type, coors) {
        this.type = type;
        this.id = id;
        this.coordinates = coors;
        this.fill = "#D8D8D8";
        this.stroke = "#000000";
        this.strokeWidth = 0.2;
        this.opacity = 1;
    }
};

export default iGeometry;