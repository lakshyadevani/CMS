class Coordinate {
  x;
  y;
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }

  toArray(){
    return [this.x, this.y];
  }

  reverse(){
    return new Coordinate(this.y, this.x);
  }
}

export default Coordinate;