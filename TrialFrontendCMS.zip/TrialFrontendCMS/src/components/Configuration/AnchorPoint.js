import React, { useState } from "react";

function AnchorPoint(props) {

  const longitudeChangeHandler = (event) => {
    props.onAnchorPointChanged(event.target.value, props.anchorPoint.y);
  };

  const latitudeChangeHandler = (event) => {
    props.onAnchorPointChanged(props.anchorPoint.x, event.target.value);
  };

  return (
    <div>
      <p>Enter longitude and latitude: </p>
      <div id="latlon">
        <input
          type="number"
          id="longitude"
          name="longitude"
          min="-180"
          max="180"
          step="0.1"
          value={props.anchorPoint.x}
          onChange={longitudeChangeHandler}
        />
        <input
          type="number"
          id="latitude"
          name="latitude"
          min="-90"
          max="90"
          step="0.1"
          value={props.anchorPoint.y}
          onChange={latitudeChangeHandler}
        />
      </div>
    </div>
  );
}

export default AnchorPoint;
