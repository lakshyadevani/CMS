import React, { useState } from "react";
import { parsePath, absolutize, normalize } from "path-data-parser";
import iGeometry from "../../utilities/iGeometry";
import FloorPlan from "../Map/FloorPlan";
import Coordinate from "../../utilities/Coordinate";

//This component receives a onFloorPlanChanged function as a prop. Pass the floor plan to this function.
function FileUpload(props) {
  const [selectedFile, setSelectedFile] = useState("");
  const [isSelected, setIsSelected] = useState(false);
  const [geometries, setGeometries] = useState([]);

  const changeHandler = (event) => {
    console.log(event);
    if (event.target.files.length > 1) {
      alert("You can only choose one file");
    } else if (event.target.files.length === 0) {
      console.log("No file chosen");
    } else {
      setSelectedFile(event.target.files[0]);
      setIsSelected(true);
      readSvgFile(event.target.files[0]);
    }
  };

  const handleSubmission = (event) => {
    console.log("Submit Button Pressed");
    console.log(event);
    if (isSelected) {
      props.onFloorPlanChanged(geometries);
    } else {
      alert("Please select a file");
    }
  };

  const getType = (segments) => {
    if (segments[0].key == "M") {
      if (segments[segments.length - 1].key == "Z") {
        return "POLYGON";
      } else {
        return "POLYLINE";
      }
    } else {
      console.log("Cannot recognize segment" + segments);
      return null;
    }
  };

  const checkValidity = (segments) => {
    //Checking validity of segments.
    if (!segments && segments.length != 0) {
      alert("Cannot Parse SVG. Invalid segments :" + segments);
      return false;
    }

    if (segments[0].key != "M") {
      alert(
        "The first segment should be an M declaration. Invalid segments :" +
          segments
      );
      return false;
    }

    segments.forEach((segment, index) => {
      if (segment.key == "M") {
        if (index !== 0) {
          alert("Cannot Parse SVG. Invalid segment at :" + segments);
          return false;
        }
      }
      if (segment.key == "Z") {
        if (index !== segments.length - 1) {
          alert("Cannot Parse SVG. Invalid segment at :" + segments);
          return false;
        }
      }
      if (segment.key == "C") {
        alert("Cannot Parse Curved Paths. Invalid segment at :" + segments);
        return false;
      }
    });
    return true;
  };

  const getCoordinates = (segments, type) => {
    let coordinates = [];
    segments.forEach((segment, index) => {
      if (segment.key === "M" || segment.key === "L") {
        coordinates.push(new Coordinate(segment.data[0], segment.data[1]));
      }
    });
    return coordinates;
  };

  const getItemValueOrNull = (svgElement, attibuteName) =>{
    if(svgElement.hasAttribute(attibuteName)){
        return svgElement.getAttribute(attibuteName);
    }
    return null;
  }

  //This function converts an SVG Path to an interface object which can then be convereted
  //to leaflet native objects.
  const parseSvg = (path_data) => {
    const segments = normalize(
      absolutize(parsePath(path_data.attributes.getNamedItem("d").nodeValue))
    );

    if (!checkValidity(segments)) {
      return null;
    } else {
        console.log("Validity Ckeck Passed");
    }

    const id = getItemValueOrNull(path_data, "id");
    console.log(id);
    const fill = getItemValueOrNull(path_data, "fill");
    console.log(fill);
    const stroke = getItemValueOrNull(path_data, "stroke");
    console.log(stroke);
    const strokeWidth = getItemValueOrNull(path_data, "stroke-width");
    console.log(strokeWidth);
    const type = getType(segments);
    console.log(type);
    const coors = getCoordinates(segments, type);
    console.log(coors);

    let iFloorPlanObject = new iGeometry(id, type, coors);
    iFloorPlanObject.fill = fill;
    iFloorPlanObject.stroke = stroke;
    iFloorPlanObject.strokeWidth = strokeWidth;
    return iFloorPlanObject;
  };

  const readSvgFile = (file) => {
    const fileReader = new FileReader();
    fileReader.onload = () => {
      const svgData = fileReader.result;
      console.log(svgData);

      const parser = new DOMParser();
      const svgDocument = parser.parseFromString(svgData, "image/svg+xml");
      const paths = svgDocument.getElementsByTagName("path");
      console.log(paths);
      let geoms = [];
      for (let i = 0; i < paths.length; i++) {
        const path = paths[i];
        geoms.push(parseSvg(path));
        console.log(
          normalize(
            absolutize(parsePath(path.attributes.getNamedItem("d").nodeValue))
          )
        );
      }

      console.log(geoms);
      setGeometries(geoms);
    };
    fileReader.readAsText(file);
  };

  return (
    <div>
      <input type="file" name="file" onChange={changeHandler} />
      {isSelected ? (
        <div>
          <p>Filename: {selectedFile.name}</p>
          <p>Filetype: {selectedFile.type}</p>
          <p>Size in bytes: {selectedFile.size}</p>
        </div>
      ) : (
        <p>Select a file to show details</p>
      )}

      <div>
        <button onClick={handleSubmission}>Submit</button>
      </div>
    </div>
  );
}

export default FileUpload;
