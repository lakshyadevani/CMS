import { useState } from "react";
import Coordinate from "../../utilities/Coordinate";
import AnchorPoint from "./AnchorPoint";
import FileUpload from "./FileUpload";

//This component receives a onConfigurationChanged function as a prop to be triggered whenever the
//floor plan needs to be redrawn.
function FloorPlanSettings(props) {
  //This function receives an array of iGeometry objects.
  const floorPlanChangeHandler = (fp) => {
    console.log("Floor PLan Changed");
    console.log(fp);
    props.onConfigurationChanged(fp, props.anchorPoint);
  };

  const anchorPointChangeHandler = (longitude, latitude) => {
    console.log("Anchor Point changed");
    console.log(longitude);
    console.log(latitude);
    props.onConfigurationChanged(
      props.floorPlan,
      new Coordinate(longitude, latitude)
    );
  };

  return (
    <div>
      <FileUpload
        floorPlan={props.floorPlan}
        onFloorPlanChanged={floorPlanChangeHandler}
      />
      <AnchorPoint
        anchorPoint={props.anchorPoint}
        onAnchorPointChanged={anchorPointChangeHandler}
      />
    </div>
  );
}

export default FloorPlanSettings;
