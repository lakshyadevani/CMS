import { parsePath, absolutize, normalize } from "path-data-parser";
import ScaleFactor from "../../utilities/ScaleFactor";
import {Polygon, Polyline} from "react-leaflet";

function FloorPlan(props) {
  console.log(props.floorPlanGeoms); //props.floorPlanGeoms is an array of type iGeometry
  let geomElements = [];

  const transformXYtoLatLngs = (coors) => {
    const ax = props.anchorPoint.x;
    const ay = props.anchorPoint.y;
    const [sx, sy] = ScaleFactor(ax, ay);
    let latlngs = [];
    coors.forEach((coor) => {
      latlngs.push([ay - coor.y / sy, ax + coor.x / sx]);
    });
    return latlngs;
  };

  const purpleOptions = { color: 'purple' }
  const polygon = [
    [51.515, -0.09],
    [51.52, -0.1],
    [51.52, -0.12],
  ]

  props.floorPlanGeoms.forEach((element, index) => {
    const latlngs = transformXYtoLatLngs(element.coordinates);
    // let options = { color: element.fill };
    let options = { color: element.fill, opacity: element.opacity, stroke: element.stroke };
    if (element.type === "POLYGON") {
      console.log("Adding a POLYGON");
      console.log(latlngs);
      geomElements.push(
        <Polygon
          key={index}
          positions={latlngs}
          pathOptions={options}
        />
      );
    } else if (element.type === "POLYLINE") {
      console.log("Adding a POLYLINE");
      console.log(latlngs);
      geomElements.push(
        <Polyline
          key={index}
          positions={latlngs}
          lineOptions={options}
        />
      );
    }else{
      console.log("Not a POLYGON or POLYLINE" + element);
    }
  });
  return (
    <div>
      {geomElements}
    </div>
  );
}

export default FloorPlan;
