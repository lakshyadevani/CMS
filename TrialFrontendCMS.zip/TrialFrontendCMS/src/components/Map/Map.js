import "./Map.css";
import "leaflet/dist/leaflet.css";
import "leaflet-draw/dist/leaflet.draw.css";

import {
  MapContainer,
  TileLayer,
} from "react-leaflet";

import AnchorMarker from "./AnchorMarker";

import { EditControl } from "react-leaflet-draw";
import FloorPlan from "./FloorPlan";
import Coordinate from "../../utilities/Coordinate";

//We receive a floor plan in the props.
function Map(props) {

  const position = [51.505, -0.09];

  console.log("Floor Plan Received");
  console.log(props.floorPlanGeoms);

  console.log("Anchor Point Received");
  console.log(props.anchorPoint);

  const anchorPointChangeHandler = (longitude, latitude)=>{
    console.log("Now changing anchorPoint from Map ["+ longitude+" , "+ latitude+"]");
    console.log(props.floorPlanGeoms);
    props.onConfigurationChanged(props.floorPlanGeoms, new Coordinate(longitude,latitude));
  }

  return (
    <MapContainer className="map" center={position} zoom={13}>
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <AnchorMarker anchorPoint={props.anchorPoint} onAnchorPointChanged={anchorPointChangeHandler}/>
      <FloorPlan anchorPoint={props.anchorPoint} floorPlanGeoms = {props.floorPlanGeoms} />
    </MapContainer>
  );
}

export default Map;
