import React, { useState, useMemo, useRef } from "react";

import "leaflet/dist/leaflet.css";
import "leaflet-draw/dist/leaflet.draw.css";
import { Marker } from "react-leaflet";
import L from "leaflet";
import Coordinate from "../../utilities/Coordinate";

import icon from "leaflet/dist/images/marker-icon.png";
import iconShadow from "leaflet/dist/images/marker-shadow.png";

function AnchorMarker(props) {

  const markerRef = useRef(null);
  console.log("Drawing Marker" + props.anchorPoint);

  let anchorIcon = L.icon({
    iconUrl: icon,
    shadowUrl: iconShadow,
    iconAnchor: [13, 41],
    iconSize: [25, 41],
    shadowAnchor: [15, 41],
    shadowSize: [41, 41],
  });

  const eventHandlers = useMemo(
    () => ({
      dragend() {
        const marker = markerRef.current;
        if (marker != null) {
          const latlng = marker.getLatLng();
          console.log(latlng);
          props.onAnchorPointChanged(latlng.lng, latlng.lat);
        }
      },
    }),
    []
  );

  return (
    <Marker
      eventHandlers={eventHandlers}
      draggable={true}
      position={props.anchorPoint.reverse().toArray()}
      icon={anchorIcon}
      ref={markerRef}
    />
  );
}

export default AnchorMarker;
